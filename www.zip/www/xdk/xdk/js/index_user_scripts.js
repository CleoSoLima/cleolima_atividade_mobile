/*jshint browser:true */
/*global $ */(function()
{
 "use strict";
 /*
   hook up event handlers 
 */
 function register_event_handlers()
 {
     var texto;
    
     
    
        /* button  #btnentrar */
    $(document).on("click", "#btnentrar", function(evt)
    {
         /*global activate_page */
         activate_page("#home"); 
         return false;
    });
    
        /* button  #btnHome */
    $(document).on("click", "#btnHome", function(evt)
    {
         /*global activate_page */
         activate_page("#home"); 
         return false;
    });
    
        /* button  #btnCategoria */
    $(document).on("click", "#btnCategoria", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#categoria"); 
         return false;
    });
    
        /* listitem  Infantíl */
    
    
        /* listitem  Didático */
    
    
        /* listitem  Romance */
    
    
        /* listitem  Tecnológico */
    
    
        /* button  #btnContatos1 */
    $(document).on("click", "#btnContatos1", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#categoria"); 
         return false;
    });
    
        /* button  #btnContatos2 */
    $(document).on("click", "#btnContatos2", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#categoria"); 
         return false;
    });
    
        /* button  #btnContatos3 */
    $(document).on("click", "#btnContatos3", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#categoria"); 
         return false;
    });
    
        /* button  #btnContatos4 */
    $(document).on("click", "#btnContatos4", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#categoria"); 
         return false;
    });
    
        /* button  #btnEnviar */
    $(document).on("click", "#btnEnviar", function(evt)
    {
        
        
        
    });
    
        /* button  #btnLimpar */
    $(document).on("click", "#btnLimpar", function(evt)
    {
       
    });
    
        /* button  #btnContatos */
    $(document).on("click", "#btnContatos", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#contatos"); 
         return false;
    });
    
        /* listitem  Tecnológico */
    
    
        /* listitem  Didático */
    
    
       
    
        /* button  #botaoEnviar */
    $(document).on("click", "#botaoEnviar", function(evt)
    {
         var nome= document.getElementById("campoNome").value;
        var email= document.getElementById("campoEmail").value;
        var sexo;
        if(document.getElementById("radioFem").checked)
           sexo = "Feminino";
        if(document.getElementById("radioMasc").checked)
          sexo="Masculino";
        
        var assunto = document.getElementById("campoAssunto");
        var nomeAssunto = assunto.options[assunto.selectedIndex].text;
        
        texto = nome + " " + email + " " + sexo + " " + nomeAssunto;
        navigator.notification.alert(texto + "-Mensagem enviada com sucesso!", "","App Livraria","Ok");
    });
    
        /* button  #botaoLimpar */
    $(document).on("click", "#botaoLimpar", function(evt)
    {
        /* your code goes here */ 
        document.getElementById("campoNome").value='';
        document.getElementById("campoEmail").value='';
        document.getElementById("radioFem").checked=false;
        document.getElementById("radioMasc").checked=false;
        document.getElementById("campoAssunto").value=0;
        document.getElementById("campoMensagem").value='';
    });
    
        /* button  #botaoMostrar */
    $(document).on("click", "#botaoMostrar", function(evt)
    {
        /* your code goes here */ 
         navigator.notification.alert(texto + "-Mensagem armazenado!", " ", "App Livraria", "Ok");
    });
    
        /* listitem  #listDidatico */
    $(document).on("click", "#listDidatico", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#didatico"); 
         return false;
    });
    
        /* listitem  #listInfantil */
    $(document).on("click", "#listInfantil", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#infantil"); 
         return false;
    });
    
        /* listitem  #listRomance */
    $(document).on("click", "#listRomance", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#romance"); 
         return false;
    });
    
        /* listitem  #listTecnologico */
    $(document).on("click", "#listTecnologico", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#tecnologico"); 
         return false;
    });
    
        /* button  #btnHistoria */
    $(document).on("click", "#btnHistoria", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#nossahistoria"); 
         return false;
    });
    
    }
 document.addEventListener("app.Ready", register_event_handlers, false);
})();
